## version 1
1. To run server
	gcc -o server gradingServer.c
	./server 8080
	
2. To run client
	gcc -o client submit.c
	./client localhost 8080 file.c loop_num sleeptime
	

## version 2
1. To run server
	gcc -o server gradingServer.c -lpthread
	./server 8080
	
2. To run client
	gcc -o client submit.c
	./client localhost 8080 file.c loop_num sleeptime timeout
	


## version 3
1. To run server
	gcc -o server gradingServer.c -lpthread
	./server 8080 num_threads
	
2. To run client
	gcc -o client submit.c
	./client localhost 8080 file.c loop_num sleeptime timeout
	

## version 4
1. To run server
	bash setup.sh
	./server 8080 num_threads
	
2. To run client
	gcc -o client submit.c
	./client new/status localhost 8080 file.c/request_id
	

