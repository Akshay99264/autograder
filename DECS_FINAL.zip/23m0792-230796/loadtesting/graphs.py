import csv

from matplotlib import pyplot as plt

def pre_processing(data):
    processed_data = []
    data = list(data)[1:]
    count = 0
    # "Clients No., Average response time,Throughput,Goodput,Timeout rate,Error Rate,Request Rate,Successfull response,Loop time"
    l = [0, 0, 0, 0]
    n = len(l)
    for i in range(len(data)):
        try:
            if data[i][0] == '':
                l[0] = count
                l[1] = l[1] / count
                processed_data.append(l)
                count = 0
                l = [0, 0, 0, 0]
            else:
                for j in range(n):
                    l[j] += float(data[i][j])
                count += 1
        except:
            pass
    return processed_data

def pre_processing_7(data):
    processed_data = []
    data = list(data)[1:]
    count = 0
    # "Clients No., Average response time,Throughput,Goodput,Timeout rate,Error Rate,Request Rate,Successfull response,Loop time"
    l = [0, 0, 0, 0]
    n = len(l)
    for i in range(len(data)):
        try:
            if data[i][0] == '':
                l[0] = count
                l[1] = l[1] / count
                l[2] = l[2] / count
                processed_data.append(l)
                count = 0
                l = [0, 0, 0, 0]
            else:
                for j in range(n):
                    l[j] += float(data[i][j])
                count += 1
        except:
            pass
    return processed_data

def throughput_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("Throughput vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("Throughput")
    x_points = [i[0] for i in data_7]

    y_points_7 = [i[2] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[2] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[2] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[2] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[2] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")

    plt.legend()
    plt.savefig("throughput_comparision.png")
    
def response_time_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("Avg response time vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("Avg response time")
    x_points = [i[0] for i in data_7]

    # y_points = [i[1] for i in data]
    y_points_7 = [i[1] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[1] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[1] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[1] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[1] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")

    # plt.plot(x_points, y_points)
    plt.legend()
    plt.savefig("response_time.png")

def goodput_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("Goodput vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("Goodput")
    x_points = [i[0] for i in data_7]

    # y_points = [i[3] for i in data]

    y_points_7 = [i[3] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[3] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[3] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[3] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[3] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")
    # plt.plot(x_points, y_points)

    plt.legend()
    plt.savefig("goodput.png")

def timeout_rate_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("Timeout vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("Timeout Rate")
    x_points = [i[0] for i in data_7]

    # y_points = [i[4] for i in data]
    y_points_7 = [i[4] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[4] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[4] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[4] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[4] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")
    # plt.plot(x_points, y_points)

    plt.legend()
    plt.savefig("timeout.png")

def error_rate_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("Error Rate vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("Error Rate")
    x_points = [i[0] for i in data_7]

    # y_points = [i[5] for i in data]
    # plt.plot(x_points, y_points)

    y_points_7 = [i[5] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[5] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[5] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[5] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[5] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")

    plt.legend()
    plt.savefig("error_rate.png")

def request_rate_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("Request Rate vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("Request Rate")
    x_points = [i[0] for i in data_7]
    # y_points = [i[6] for i in data]

    y_points_7 = [i[6] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[6] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[6] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[6] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[6] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")
    
    plt.legend()
    plt.savefig("request_rate.png")

with open('analysis_data7.csv') as f:
    data_7 = csv.reader(f)
    data_7 = pre_processing_7(data_7)

with open('analysis_data8.csv') as f:
    data_8 = csv.reader(f)
    data_8 = pre_processing(data_8)

with open('analysis_data9_10.csv') as f:
    data_9_10 = csv.reader(f)
    data_9_10 = pre_processing(data_9_10)

with open('analysis_data9_20.csv') as f:
    data_9_20 = csv.reader(f)
    data_9_20 = pre_processing(data_9_20)

with open('analysis_data9_40.csv') as f:
    data_9_40 = csv.reader(f)
    data_9_40 = pre_processing(data_9_40)

print(len(data_7))
print(len(data_8))
print(len(data_9_10))
print(len(data_9_20))
print(len(data_9_20))


throughput_graph(data_7, data_8, data_9_10, data_9_20, data_9_40)
response_time_graph(data_7, data_8, data_9_10, data_9_20, data_9_40)
# goodput_graph(data_7, data_8, data_9_10, data_9_20, data_9_40)
# timeout_rate_graph(data_7, data_8, data_9_10, data_9_20, data_9_40)
# error_rate_graph(data_7, data_8, data_9_10, data_9_20, data_9_40)
# request_rate_graph(data_7, data_8, data_9_10, data_9_20, data_9_40)



