import csv

from matplotlib import pyplot as plt


def pre_process_cpu_utilization_data(data):
    count = 1
    processed_data = []
    l = [0, 0]
    current_clients = 0
    data = list(data)
    for i in range(len(data)):
        # try:
        if (data[i][1] == 'r' or data[i][1] == 'procs'):
            continue
        if (current_clients != int(data[i][0])):
            current_clients = int(data[i][0])
            l[1] = l[1] / count
            processed_data.append(l)
            count = 0
            l = [int(data[i][0]), 0]
        else:
            try:
                l[1] += float(data[i][13]) + float(data[i][14])
            except:
                print(data[i])
            count += 1
    l[1] = l[1] / count
    processed_data.append(l)
        # except:
        #     pass
    return processed_data

def pre_process_threads_data(data):
    count = 0
    processed_data = []
    data = list(data)
    l = [0, 0]
    try:
        for i in data:
            if i[0] == '':
                l[1] = l[1] / count
                processed_data.append(l)
                l = [0, 0]
                count = 0
            else:
                l[0] = int(i[0])
                l[1] += int(i[1])
                count += 1
        l[1] = l[1] / count
        l[0] = int(i[0])
        processed_data.append(l)
    except:
        pass
    return processed_data



def threads_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("Avg Threads vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("Avg Threads")
    x_points = [i[0] for i in data_7]

    y_points_7 = [i[1] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[1] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[1] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[1] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[1] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")

    plt.legend()
    plt.savefig("threads.png")

def cpu_utilization_graph(data_7, data_8, data_9_10, data_9_20, data_9_40):
    plt.clf()
    plt.title("CPU Utilization in % vs No of clients")
    plt.xlabel("No of clients.")
    plt.ylabel("CPU Utilization in %")

    x_points = [i[0] for i in data_7]
    y_points_7 = [i[1] for i in data_7]
    plt.plot(x_points, y_points_7, color="red", label="Single Thread")

    y_points_8 = [i[1] for i in data_8]
    plt.plot(x_points, y_points_8, color="hotpink", label="Multithread with create destroy")

    y_points_9_10 = [i[1] for i in data_9_10]
    plt.plot(x_points, y_points_9_10, color="green", label="Thread pool (10)")

    y_points_9_20 = [i[1] for i in data_9_20]
    plt.plot(x_points, y_points_9_20, color="black", label="Thread pool (20)")

    y_points_9_40 = [i[1] for i in data_9_40]
    plt.plot(x_points, y_points_9_40, color="blue", label="Thread pool (40)")

    plt.legend()
    plt.savefig("cpu_utilization.png")


with open('threads7.csv') as f:
    data_7 = csv.reader(f)
    data_7 = pre_process_threads_data(data_7)

with open('threads8.csv') as f:
    data_8 = csv.reader(f)
    data_8 = pre_process_threads_data(data_8)

with open('threads9_10.csv') as f:
    data_9_10 = csv.reader(f)
    data_9_10 = pre_process_threads_data(data_9_10)

with open('threads9_20.csv') as f:
    data_9_20 = csv.reader(f)
    data_9_20 = pre_process_threads_data(data_9_20)

with open('threads9_40.csv') as f:
    data_9_40 = csv.reader(f)
    data_9_40 = pre_process_threads_data(data_9_40)

threads_graph(data_7, data_8, data_9_10, data_9_20, data_9_40)

with open('cpu_utilization7.csv') as f:
    data_7 = csv.reader(f)
    data_7 = pre_process_cpu_utilization_data(data_7)

with open('cpu_utilization8.csv') as f:
    data_8 = csv.reader(f)
    data_8 = pre_process_cpu_utilization_data(data_8)

with open('cpu_utilization9_10.csv') as f:
    data_9_10 = csv.reader(f)
    data_9_10 = pre_process_cpu_utilization_data(data_9_10)

with open('cpu_utilization9_20.csv') as f:
    data_9_20 = csv.reader(f)
    data_9_20 = pre_process_cpu_utilization_data(data_9_20)

with open('cpu_utilization9_40.csv') as f:
    data_9_40 = csv.reader(f)
    data_9_40 = pre_process_cpu_utilization_data(data_9_40)


cpu_utilization_graph(data_7, data_8, data_9_10, data_9_20[:15], data_9_40[:15])