#include<stdio.h>
int main()
{
    printf("Akshay Patidar")
    return 0;
}