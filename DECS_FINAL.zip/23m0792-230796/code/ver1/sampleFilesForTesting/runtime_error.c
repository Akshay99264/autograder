#include <stdio.h>
int main()
{
    int num = 10, den = 0;
    int result = num / den;
    printf("1 2 3 4 5 6 7 8 9 100");
    return 0;
}
