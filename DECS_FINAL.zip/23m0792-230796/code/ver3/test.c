#include<stdio.h>
int main()
{
    printf("Akshay Patidar\n");
    return 0;
}