#include <stdio.h>

int main(){
    int a[2];
    // a[3] = 6;
    // while(1);
    printf("Hello World");
}